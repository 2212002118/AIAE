/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClienteServidor;
import java.io.*;
import java.net.*;
/**
 *
 * @author Alumno08
 */
public class Client {
    
    private static final String url="localhost";
    private static final int port=1234;
    
    public static void main(String[] args) {
        int menu=0;
        try {
            try (Socket cliente = new Socket(url, port)) {
                InputStream is;
                BufferedReader br;
                OutputStream os;
                DataInputStream dis;
                DataOutputStream dos;
                try (InputStreamReader isr = new InputStreamReader(System.in)) {
                    is = cliente.getInputStream();
                    br = new BufferedReader(isr);
                    os = cliente.getOutputStream();
                    dis = new DataInputStream(is);
                    dos = new DataOutputStream(os);
                    //Se hacen cosas
                    do{
                        System.out.println("Que tipo de operacion quieres\n");
                        System.out.println("1)Suma 2)Resta 3)Multiplicacion 4)Division 0)Salir\n");
                        String tipo = br.readLine();
                        dos.writeUTF(tipo);
                        if (tipo.equals("0")) {
                            System.out.println("Saliendo...");
                            break;
                        } else if(Integer.parseInt(tipo)>=0 && Integer.parseInt(tipo)<5){
                        
                            System.out.println("\nDame un numero para enviar al servidor: ");
                            String num1 = br.readLine();
                            dos.writeUTF(num1);

                            System.out.println("\nDame un otro numero para enviar al servidor: ");
                            String num2 = br.readLine();
                            dos.writeUTF(num2);

                            String resultado = dis.readUTF();
                            System.out.println("\nEl resultado es: " + resultado+"\n________________________________________________________\n");
                        }  else {
                            System.out.println("Entrada no valida...\n________________________________________________________\n");
                        }
                    }while(menu==0);
                }
                
                //Cerrado
                dos.close();
                dis.close();
                os.close();
                br.close();
                is.close();
            }
            
        } catch (IOException ex) {
            System.err.println("Error en: "+ex.getLocalizedMessage());
        }
    }
}
