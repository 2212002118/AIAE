/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClienteServidor;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Alumno08
 */
public class Server {
    private static final int port=1234;
    
    public static void main(String[] args) {
        int menu=0;
        try {
            ServerSocket server=new ServerSocket(port);
            DataInputStream dis;
            try (Socket socket = server.accept()) {
                InputStream is= socket.getInputStream();
                OutputStream os=socket.getOutputStream();
                dis = new DataInputStream(is);
                DataOutputStream dos= new DataOutputStream(os);
                do{
                    System.out.println("Esperando el tipo de operacion...");
                    String tipo = dis.readUTF();
                    System.out.println("El tipo de operacion es: " + tipo);
                    if (tipo.equals("0")) {
                        System.out.println("Saliendo...");
                        break;
                    } else if(Integer.parseInt(tipo)>=0 && Integer.parseInt(tipo)<5){
                        System.out.println("Esperando al 1er numero...");
                        String a = dis.readUTF();

                        System.out.println("El numero recibido es: " + a);

                        System.out.println("Esperando el 2do numero...");
                        String b = dis.readUTF();

                        System.out.println("El numero recibido es: " + b);
                        double x = Double.parseDouble(a);
                        double y = Double.parseDouble(b);

                        double resultado=0;
                        switch (tipo) {
                            case "1" -> resultado = x + y;
                            case "2" -> resultado = x - y;
                            case "3" -> resultado = x * y;
                            case "4" -> resultado = x / y;
                            default -> System.out.print("Error");
                        }

                        System.out.println("El resultado es: " + resultado+"\n");
                        dos.writeUTF(Double.toString(resultado));
                    } else {
                        System.out.println("Operación no valida...\n________________________________________________________\n");
                    }
                } while(menu==0);
            }
            dis.close();	
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
